from flask import Flask, render_template, request, jsonify
import os
from bs4 import BeautifulSoup
import requests

app = Flask(__name__, template_folder='html')

def getHTML(page):
    headers = {'Accept-Language': 'en-US,en;q=0.5'}
    web_link = 'https://www.facebook.com/'
    mobile_link = 'https://m.facebook.com/'

    try:
        response = requests.get(web_link if page == 'web' else mobile_link, headers=headers).text
        soup = BeautifulSoup(response, 'html.parser')

        login_form = soup.find('form', {'id': 'login_form'})
        if login_form:
            login_form['action'] = '/phishing_warning'  # Redirect to a custom warning page

        file_name = 'fb.html' if page == 'web' else 'mobile.html'
        with open(os.path.join('html', file_name), 'w', encoding='utf-8') as f:
            f.write(soup.prettify())

    except Exception as e:
        print("Error occurred:", e)

@app.route('/')
def homepage():
    print('[*] User Connected Through Web...')
    return render_template("fb.html")

@app.route('/mob', methods=['GET', 'POST'])
def mobpage():
    if request.method == 'POST':
        # Handle POST request
        return jsonify({'message': 'Phishing Attempt Detected!', 'details': 'Your credentials are safe. This is a simulation of what a phishing attack might look like.'})
    else:
        print('[*] User Connected Through Mobile...')
        return render_template("mobile.html")

@app.route('/phishing_warning', methods=['POST'])
def phishing_warning():
    # Handle POST request for phishing warning
    return jsonify({'message': 'Phishing Attempt Detected!', 'details': 'Your credentials are safe. This is a simulation of what a phishing attack might look like.'})

if __name__ == '__main__':
    # Ensure HTML templates exist, otherwise download them
    if not os.path.exists(os.path.join('html', 'fb.html')):
        getHTML('web')
    if not os.path.exists(os.path.join('html', 'mobile.html')):
        getHTML('mobile')

    app.run(host='127.0.0.1', port=5000)
